CREATE VIEW v_stu AS
  SELECT
    `s`.`id`    AS `sid`,
    `s`.`sname` AS `sname`,
    `c`.`cname` AS `cname`
  FROM `stu1`.`stu` `s`
    JOIN `stu1`.`classes` `c`
  WHERE (`s`.`cid` = `c`.`id`);

